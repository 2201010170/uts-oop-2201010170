
package kariawan;

/**
 *
 * @author User
 */
public class Kariawan {

   
    public static void main(String[] args) {
        new Data().setVisible(true);
    }
    
}
